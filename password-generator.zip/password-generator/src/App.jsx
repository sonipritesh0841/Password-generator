import React from "react";
import PasswordGenerator from "./components/PasswordGenerator";

const App = () => {
  return (
    <div>
      <PasswordGenerator />
    </div>
  );
};

export default App;
